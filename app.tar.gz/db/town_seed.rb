Town.where(name: 'Belmont').first.update_attributes(hotness: 4)

Town.where(name: 'Lexington').first.update_attributes(hotness: 4)

Town.where(name: 'Watertown').first.update_attributes(hotness: 4)

Town.where(name: 'Westwood').first.update_attributes(hotness: 4)

Town.where(name: 'Malden').first.update_attributes(hotness: 4)

Town.where(name: 'Quincy').first.update_attributes(hotness: 4)

Town.where(name: 'Concord').first.update_attributes(hotness: 4)

Town.where(name: 'Waltham').first.update_attributes(hotness: 4)

Town.where(name: 'Boston').first.update_attributes(hotness: 4)

Town.where(name: 'Somerville').first.update_attributes(hotness: 4)

Town.where(name: 'Natick').first.update_attributes(hotness: 4)

Town.where(name: 'Arlington').first.update_attributes(hotness: 4)

Town.where(name: 'Lincoln').first.update_attributes(hotness: 4)

Town.where(name: 'Winchester').first.update_attributes(hotness: 4)

Town.where(name: 'Wellesley').first.update_attributes(hotness: 4)

Town.where(name: 'Weston').first.update_attributes(hotness: 4)

Town.where(name: 'Brookline').first.update_attributes(hotness: 4)

Town.where(name: 'Needham').first.update_attributes(hotness: 4)

Town.where(name: 'Newton').first.update_attributes(hotness: 4)

Town.where(name: 'Cambridge').first.update_attributes(hotness: 4)

Town.where(name: 'Acton').first.update_attributes(hotness: 4)