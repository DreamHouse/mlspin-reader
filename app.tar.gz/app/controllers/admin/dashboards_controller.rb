class Admin::DashboardsController < ApplicationController
  layout "admin"
  
  def show
   
  end
end