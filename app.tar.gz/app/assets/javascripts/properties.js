$(function() {
  $('#home_detail_carousel').carousel({
    'interval': 10000
  });

})